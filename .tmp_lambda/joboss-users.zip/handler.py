import json
import boto3
import os
from datetime import datetime, timezone
from decimal import Decimal

dynamodb = boto3.resource("dynamodb")

USERS_TABLE_NAME = os.environ.get("USERS_TABLE_NAME", "joboss-users")
users_table = dynamodb.Table(USERS_TABLE_NAME)


def decimal_to_native(obj):
    if isinstance(obj, Decimal):
        if obj % 1 == 0:
            return int(obj)
        return float(obj)

    raise TypeError


def build_response(status_code, body):
    return {
        "statusCode": status_code,
        "headers": {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*",
            "Access-Control-Allow-Headers": "Content-Type,Authorization",
            "Access-Control-Allow-Methods": "GET,POST,PUT,OPTIONS"
        },
        "body": json.dumps(body, default=decimal_to_native)
    }


def get_claims_from_event(event):
    return (
        event.get("requestContext", {})
        .get("authorizer", {})
        .get("claims", {})
    )


def get_user_id_from_event(event):
    claims = get_claims_from_event(event)
    return claims.get("sub")


def get_user_email_from_event(event):
    claims = get_claims_from_event(event)
    return claims.get("email", "")


def get_http_method(event):
    return (
        event.get("httpMethod")
        or event.get("requestContext", {}).get("http", {}).get("method")
        or ""
    ).upper()


def normalize_user(user):
    if not user:
        return user

    user.setdefault("fullName", "")
    user.setdefault("email", "")
    user.setdefault("preferredLocation", "")
    user.setdefault("searchRadius", 20)
    user.setdefault("desiredRole", "")
    user.setdefault("experienceLevel", "")
    user.setdefault("plan", "FREE")
    user.setdefault("role", "USER")
    user.setdefault("autoApply", False)

    return user


def validate_user_fields(body):
    if "plan" in body and body["plan"] not in ["FREE", "PREMIUM"]:
        return "plan must be FREE or PREMIUM"

    if "role" in body and body["role"] not in ["USER", "ADMIN"]:
        return "role must be USER or ADMIN"

    if "autoApply" in body and not isinstance(body["autoApply"], bool):
        return "autoApply must be true or false"

    if "searchRadius" in body:
        if not isinstance(body["searchRadius"], (int, float)):
            return "searchRadius must be a number"

        if body["searchRadius"] < 0:
            return "searchRadius must be greater than or equal to 0"

    return None


def get_user_profile(event):
    user_id = get_user_id_from_event(event)

    if not user_id:
        return build_response(401, {
            "message": "Missing user identity"
        })

    response = users_table.get_item(
        Key={
            "userId": user_id
        }
    )

    user = response.get("Item")

    if not user:
        return build_response(404, {
            "message": "User profile not found"
        })

    return build_response(200, {
        "message": "User profile fetched successfully",
        "user": normalize_user(user)
    })


def create_user_profile(event):
    body = json.loads(event.get("body") or "{}")

    user_id = get_user_id_from_event(event)

    if not user_id:
        return build_response(401, {
            "message": "Missing user identity"
        })

    validation_error = validate_user_fields(body)
    if validation_error:
        return build_response(400, {
            "message": validation_error
        })

    now = datetime.now(timezone.utc).isoformat()

    user_item = {
        "userId": user_id,
        "fullName": body.get("fullName", ""),
        "email": body.get("email") or get_user_email_from_event(event),
        "preferredLocation": body.get("preferredLocation", ""),
        "searchRadius": body.get("searchRadius", 20),
        "desiredRole": body.get("desiredRole", ""),
        "experienceLevel": body.get("experienceLevel", ""),
        "plan": body.get("plan", "FREE"),
        "role": body.get("role", "USER"),
        "autoApply": body.get("autoApply", False),
        "createdAt": now,
        "updatedAt": now
    }

    users_table.put_item(
        Item=user_item,
        ConditionExpression="attribute_not_exists(userId)"
    )

    return build_response(201, {
        "message": "User profile created successfully",
        "user": user_item
    })


def update_user_profile(event):
    body = json.loads(event.get("body") or "{}")
    user_id = get_user_id_from_event(event)

    if not user_id:
        return build_response(401, {
            "message": "Missing user identity"
        })

    validation_error = validate_user_fields(body)
    if validation_error:
        return build_response(400, {
            "message": validation_error
        })

    allowed_fields = [
        "fullName",
        "email",
        "preferredLocation",
        "searchRadius",
        "desiredRole",
        "experienceLevel",
        "plan",
        "role",
        "autoApply"
    ]

    update_parts = []
    expression_values = {}
    expression_names = {}

    for field in allowed_fields:
        if field in body:
            placeholder_name = f"#{field}"
            placeholder_value = f":{field}"

            update_parts.append(f"{placeholder_name} = {placeholder_value}")
            expression_names[placeholder_name] = field
            expression_values[placeholder_value] = body[field]

    if not update_parts:
        return build_response(400, {
            "message": "No valid fields were provided for update"
        })

    update_parts.append("#updatedAt = :updatedAt")
    expression_names["#updatedAt"] = "updatedAt"
    expression_values[":updatedAt"] = datetime.now(timezone.utc).isoformat()

    response = users_table.update_item(
        Key={
            "userId": user_id
        },
        UpdateExpression="SET " + ", ".join(update_parts),
        ExpressionAttributeNames=expression_names,
        ExpressionAttributeValues=expression_values,
        ReturnValues="ALL_NEW"
    )

    return build_response(200, {
        "message": "User profile updated successfully",
        "user": normalize_user(response.get("Attributes", {}))
    })


def handler(event, context):
    try:
        method = get_http_method(event)

        if method == "GET":
            return get_user_profile(event)

        if method == "POST":
            return create_user_profile(event)

        if method == "PUT":
            return update_user_profile(event)

        if method == "OPTIONS":
            return build_response(200, {
                "message": "CORS preflight successful"
            })

        return build_response(405, {
            "message": f"Method {method} is not allowed"
        })

    except users_table.meta.client.exceptions.ConditionalCheckFailedException:
        return build_response(409, {
            "message": "User profile already exists"
        })

    except json.JSONDecodeError:
        return build_response(400, {
            "message": "Invalid JSON body"
        })

    except Exception as e:
        return build_response(500, {
            "message": "Failed to process user request",
            "error": str(e)
        })